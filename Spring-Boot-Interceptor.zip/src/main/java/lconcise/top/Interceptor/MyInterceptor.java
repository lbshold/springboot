package lconcise.top.Interceptor;

import lombok.extern.java.Log;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by liusj 2019/6/29
 */
@Log
public class MyInterceptor extends HandlerInterceptorAdapter {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        log.info("MyInterceptor == preHandler ");
        long startTime = System.nanoTime();
        request.setAttribute("startTime", startTime);
        return super.preHandle(request, response, handler);
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        log.info("MyInterceptor == postHandle ");
        super.postHandle(request, response, handler, modelAndView);
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        log.info("MyInterceptor == afterCompletion ");

        Long startTime = (Long) request.getAttribute("startTime");
        long endTime = System.nanoTime();
        // 打印出接口请求时间
        log.info("This method expired :" + (endTime - startTime) / 1000000 + " 毫秒");

        super.afterCompletion(request, response, handler, ex);
    }
}
