package top.lconcise.controller;

import org.springframework.web.bind.annotation.*;
import top.lconcise.entity.User;
import top.lconcise.mapper.UserMapper;
import top.lconcise.page.Page;
import top.lconcise.page.UserParam;

import javax.annotation.Resource;
import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    @Resource
    private UserMapper userMapper;

    @GetMapping(path = "/{id}")
    public User getOne(@PathVariable Long id) {
        return userMapper.getOne(id);
    }

    @PostMapping(path = "/getPage")
    public Page<User> getPage(@RequestBody UserParam userParam) {
        List<User> list = userMapper.getPage(userParam);
        Integer count = userMapper.getCount(userParam);
        Page<User> page = new Page<>(userParam, count, list);
        return page;
    }

    @GetMapping
    public List<User> getAll() {
        return userMapper.getAll();
    }

    @PostMapping
    public void insert(@RequestBody User user) {
        userMapper.insert(user);
    }

    @PutMapping
    public void update(@RequestBody User user) {
        userMapper.update(user);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        userMapper.delete(id);
    }
}
