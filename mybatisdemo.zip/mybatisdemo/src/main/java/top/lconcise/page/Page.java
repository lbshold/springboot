package top.lconcise.page;

import java.io.Serializable;
import java.util.List;

public class Page<T> implements Serializable {

    private int currentPage;
    private int totalPage;
    private long totalNumber;
    private List<T> list;

    public Page(PageParam pageParam, int totalNumber, List<T> list) {
        this.currentPage = pageParam.getCurrentPage();
        if (totalNumber == 0) {
            this.totalPage = 0;
        } else {
            this.totalPage = (totalNumber & 1) == 1 ? totalNumber / pageParam.getPageSize() + 1 : totalNumber / pageParam.getCurrentPage();
        }
        this.totalNumber = totalNumber;
        this.list = list;
    }


    public int getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public long getTotalNumber() {
        return totalNumber;
    }

    public void setTotalNumber(long totalNumber) {
        this.totalNumber = totalNumber;
    }

    public List<T> getList() {
        return list;
    }

    public void setList(List<T> list) {
        this.list = list;
    }
}
