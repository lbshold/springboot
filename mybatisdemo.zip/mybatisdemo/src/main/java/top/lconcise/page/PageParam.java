package top.lconcise.page;

public class PageParam {

    private int beginLine;       // 起始行
    private int pageSize = 3;
    private int currentPage = 0; // 当前页

    public int getBeginLine() {
        return currentPage * pageSize;
    }

    public void setBeginLine(int beginLine) {
        this.beginLine = beginLine;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
    }
}
