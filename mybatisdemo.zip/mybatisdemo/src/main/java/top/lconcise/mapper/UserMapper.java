package top.lconcise.mapper;

import top.lconcise.entity.User;
import top.lconcise.page.UserParam;

import java.util.List;

public interface UserMapper {

    User getOne(Long id);

    List<User> getAll();

    void insert(User user);

    void update(User user);

    void delete(Long id);

    List<User> getPage(UserParam userParam);

    Integer getCount(UserParam userParam);
}
