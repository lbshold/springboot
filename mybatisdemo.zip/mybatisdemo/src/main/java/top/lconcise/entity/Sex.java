package top.lconcise.entity;

public enum Sex {
    MAN, WOMAN
}
