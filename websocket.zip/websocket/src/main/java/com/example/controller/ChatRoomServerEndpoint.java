package com.example.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RestController;

import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

import static com.example.utils.WebSocketUtils.ONLINE_USER_SESSIONS;
import static com.example.utils.WebSocketUtils.sendMessageAll;


@RestController
@ServerEndpoint("/chat-room/{username}")
public class ChatRoomServerEndpoint {

    private static final Logger LOGGER = LoggerFactory.getLogger(ChatRoomServerEndpoint.class);

    @OnOpen
    public void openSession(@PathParam("username") String username, Session session) {
        ONLINE_USER_SESSIONS.put(username, session);
        String message = "欢迎用户 " + username + " 来到聊天室";
        LOGGER.info(username + " 登录");
        sendMessageAll(message);
    }

    @OnMessage
    public void onMessage(@PathParam("username") String username, String message) {
        LOGGER.info("发送消息 " + message);
        sendMessageAll("用户 " + username + " " + message);
    }

    @OnClose
    public void onClose(@PathParam("username") String username, Session session) {
        ONLINE_USER_SESSIONS.remove(username);
        sendMessageAll("用户 " + username + " 已经离开聊天室！");
        try {
            session.close();
        } catch (Exception e) {
            LOGGER.error("onClose error " + e);
        }
    }
}
