package com.example.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.websocket.RemoteEndpoint;
import javax.websocket.Session;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class WebSocketUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(WebSocketUtils.class);

    public static final Map<String, Session> ONLINE_USER_SESSIONS = new ConcurrentHashMap<>();

    /**
     * 发送消息.
     * @param session
     * @param message
     */
    public static void sendMessage(Session session,String message){
        if(session==null){
            return;
        }
        final RemoteEndpoint.Basic basicRemote = session.getBasicRemote();
        if(basicRemote == null){
            return;
        }
        try{
            basicRemote.sendText(message);
        }catch (Exception e){
            LOGGER.error("sendMessage IOException",e);
        }
    }

    public static void sendMessageAll(String message){
        ONLINE_USER_SESSIONS.forEach((sessionId,session)->{
            sendMessage(session,message);
        });
    }
}
