package top.lconcise.bus.service.Impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import top.lconcise.bus.entity.User;
import top.lconcise.bus.repository.UserRepository;
import top.lconcise.bus.service.UserService;
import top.lconcise.view.Message;

import javax.transaction.Transactional;

/**
 * 用户服务类.
 */
@Service
@Transactional
public class UserServiceImpl implements UserService {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserService.class);

    @Autowired
    private UserRepository userRepository;

    @Override
    public Message create(User user) {
        try {
            userRepository.save(user);
            return new Message(Boolean.TRUE, "创建成功");
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return new Message(Boolean.FALSE, "创建失败");
        }
    }

    @Override
    public Message update(User user) {
        try {
            userRepository.save(user);
            return new Message(Boolean.TRUE, "更新成功");
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return new Message(Boolean.FALSE, "更新失败");
        }
    }

    @Override
    public Message findAll() {
        return new Message(Boolean.TRUE, userRepository.findAll());
    }

    @Override
    public Message deletedById(Long id) {
        try {
            userRepository.deleteById(id);
            return new Message(Boolean.TRUE, "删除成功");
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return new Message(Boolean.FALSE, "删除失败");
        }
    }
}
