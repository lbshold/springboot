package top.lconcise.bus.service;

import top.lconcise.bus.entity.User;
import top.lconcise.view.Message;

/**
 * 用户服务类.
 */
public interface UserService {

    Message create(User user);

    Message update(User user);

    Message findAll();

    Message deletedById(Long id);
}
