package top.lconcise.bus.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import top.lconcise.bus.entity.User;

/**
 * 用户访问数据库接口.
 */
public interface UserRepository extends JpaRepository<User, Long> {
}
