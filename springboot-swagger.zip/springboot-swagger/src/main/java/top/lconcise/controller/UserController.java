package top.lconcise.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import top.lconcise.bus.entity.User;
import top.lconcise.bus.service.UserService;
import top.lconcise.view.Message;

@Api(value = "用户相关操作", tags = "用户相关操作")
@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    @ApiOperation("创建用户")
    @PostMapping
    public Message<String> create(@RequestBody User bean) {
        return userService.create(bean);
    }

    @ApiOperation("修改用户")
    @PutMapping
    public Message<String> put(@RequestBody User bean) {
        return userService.update(bean);
    }

    @ApiOperation("获取所有用户")
    @GetMapping
    public Message findAll() {
        return userService.findAll();
    }

    @ApiOperation("根据id删除用户")
    @DeleteMapping(value = "/{id}")
    public Message deleteById(@PathVariable("id") Long id) {
        return userService.deletedById(id);
    }
}
