package com.lconcise.simpleFramework.bus.repository;

import com.lconcise.simpleFramework.bus.entity.User;
import org.springframework.data.repository.CrudRepository;

/**
 * 用户访问数据库接口.
 */
public interface UserRepository extends CrudRepository<User, Long> {

    User findByUsername(String name);
}
