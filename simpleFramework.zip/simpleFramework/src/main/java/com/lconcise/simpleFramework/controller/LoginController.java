package com.lconcise.simpleFramework.controller;

import com.lconcise.simpleFramework.view.LoginView;
import com.lconcise.simpleFramework.view.Message;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LoginController {

    @ApiOperation(value = "用户登录", notes = "用户登录操作")
    @PatchMapping(path = "/loginz")
    public Message login(@RequestBody LoginView loginView) {
        Message message = new Message();
        UsernamePasswordToken token = new UsernamePasswordToken(loginView.getUsername(), loginView.getPassword());
        Subject currentUser = SecurityUtils.getSubject();

        try {
            currentUser.login(token);
        } catch (Exception e) {
            message.setLogin(Boolean.FALSE);
            if (UnknownAccountException.class.getName().equals(e)) {
                message.setData("账号不存在");
                return message;
            } else if ((IncorrectCredentialsException.class.getName().equals(e))) {
                message.setData("用户名或者密码错误");
                return message;
            }
        }

        // 验证是否成功
        if (currentUser.isAuthenticated()) {
            message.setSuccess(Boolean.TRUE);
            message.setData("登录成功");
            return message;
        } else {
            token.clear();
            message.setData("登录失败");
            return message;
        }
    }
}
