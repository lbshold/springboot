package com.lconcise.simpleFramework.bus.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * 权限.
 */
@Entity
@Table(name = "t_sys_permission")
public class Permission extends IdEntity {

    private static final String PERMISSION_FORMAT = "%s:%s:%s";

    private String module;
    private String name;
    private String operation;
    private String label;

    public String getPermission() {
        return String.format(PERMISSION_FORMAT, module, name, operation);
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }
}
