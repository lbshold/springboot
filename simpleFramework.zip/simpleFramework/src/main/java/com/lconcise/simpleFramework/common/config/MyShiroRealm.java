package com.lconcise.simpleFramework.common.config;

import com.lconcise.simpleFramework.bus.entity.User;
import com.lconcise.simpleFramework.bus.repository.UserRepository;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 自我实现realm.
 */
public class MyShiroRealm extends AuthorizingRealm {

    @Autowired
    private UserRepository userRepository;

    /*主要是用来进行身份认证的，也就是说验证用户输入的账号和密码是否正确。*/
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {

        UsernamePasswordToken token = (UsernamePasswordToken) authenticationToken;

        User user = userRepository.findByUsername(token.getUsername());
        if (user != null) {
            // 若存在，将此user放到登录认证中，无需自己做密码对比，shiro 会为我们做密码对比
            SimpleAuthenticationInfo authenticationInfo = new SimpleAuthenticationInfo(user.getUsername(), user.getPassword(), getName());

            return authenticationInfo;
        } else {
            throw new UnknownAccountException();
        }
    }

    /*角色和权限*/
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        return null;
    }
}
