package com.lconcise.simpleFramework.bus.entity;

import javax.persistence.*;
import java.util.List;

/**
 * 角色.
 */
@Entity
@Table(name = "t_sys_role")
public class Role extends IdEntity {

    private String roleName;
    private String description;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "t_role_permission",
            joinColumns = {@JoinColumn(name = "role_id")},
            inverseJoinColumns = {@JoinColumn(name = "permission_id")}
    )
    private List<Permission> permissions;

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<Permission> getPermissions() {
        return permissions;
    }

    public void setPermissions(List<Permission> permissions) {
        this.permissions = permissions;
    }
}
