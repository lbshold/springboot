package com.lconcise.simpleFramework.view;

/**
 * 响应消息.
 *
 * @param <T> 消息内容
 */
public class Message<T extends Object> {
    private Boolean success;
    private Object data;
    private Boolean login;

    public Message() {
        this.login = Boolean.TRUE;
    }

    public Message(Boolean success, Object data, Boolean login) {
        this.success = success;
        this.data = data;
        this.login = login;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public Boolean getLogin() {
        return login;
    }

    public void setLogin(Boolean login) {
        this.login = login;
    }
}
