package top.lconcise.filterdemo;

import lombok.extern.java.Log;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
@Log
public class Application {

    @RequestMapping(value = "/")
    public String home() {
        log.info("接口请求");
        return "Hello Filter World";
    }

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

}
