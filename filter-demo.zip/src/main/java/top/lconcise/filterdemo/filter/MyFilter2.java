package top.lconcise.filterdemo.filter;

import lombok.extern.java.Log;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;

import javax.servlet.*;
import javax.servlet.FilterConfig;
import javax.servlet.annotation.WebFilter;
import java.io.IOException;

/**
 * Created by liusj on 2019/6/24
 */
@Configuration// 将此Filter交给Spring容器管理
@WebFilter(urlPatterns = "/", filterName = "MyFilter2")
@Order(1)// 指定过滤器的执行顺序，值越大越靠后执行
@Log
public class MyFilter2 implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        log.info("过滤器 == MyFilter2 == init");
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        log.info("过滤器 == MyFilter2 == before");
        filterChain.doFilter(servletRequest,servletResponse);
        log.info("过滤器 == MyFilter2 == after");
    }

    @Override
    public void destroy() {
        log.info("过滤器 == MyFilter2 == destroy");
    }
}
