package top.lconcise.filterdemo.filter;


import lombok.extern.java.Log;

import javax.servlet.*;
import javax.servlet.FilterConfig;
import java.io.IOException;

/**
 * Created by liusj on 2019/6/24
 */
@Log
public class MyFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        log.info("过滤器 == MyFilter == init");
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        log.info("过滤器 == MyFilter == before");
        filterChain.doFilter(servletRequest,servletResponse);
        log.info("过滤器 == MyFilter == after");
    }

    @Override
    public void destroy() {
        log.info("过滤器 == MyFilter == destroy");
    }
}
