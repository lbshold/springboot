docker rmi suyu/springbootwebsocket:v1.0.0
